/* ============================================================================
 * WISHMAGIC CLAY ADMIN APP — SERVICE WORKER (v1.4.0)
 * Enables standalone PWA installation while ensuring all /api/* requests
 * always go directly to the live Cloudflare Worker + D1 backend.
 * ============================================================================ */

const CACHE_NAME = 'wishmagic-clay-admin-v1.4.0';
const APP_SHELL_ASSETS = [
  '/css/clay-admin-app.css',
  '/js/clay-admin-app.js',
  '/wm-clay-admin.webmanifest'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL_ASSETS).catch(() => {}))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  // Never cache API mutations or live backend calls — always hit live server!
  if (url.pathname.startsWith('/api/') || event.request.method !== 'GET') {
    return;
  }
  event.respondWith(
    fetch(event.request)
      .then((res) => {
        if (res && res.status === 200 && APP_SHELL_ASSETS.includes(url.pathname)) {
          const clone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone)).catch(() => {});
        }
        return res;
      })
      .catch(() => caches.match(event.request))
  );
});

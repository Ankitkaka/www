/* ============================================================================
 * WISHMAGIC CLAYMORPHISM ADMIN APP — LIVE FULL-STACK CONTROLLER (v1.4.0)
 * Directly connected to Cloudflare Worker + D1 + Backblaze B2 + ImgBB APIs.
 * Every change made here updates the live WishMagic website immediately.
 * ============================================================================ */

(function () {
  'use strict';

  const SECRET_ADMIN_PREFIX = '/admin/anktech/anktech/admin';

  // Canonical Mapping of All 21 Admin Sections
  const SECTION_META = {
    'overview': {
      title: 'Dashboard & Live Website Control',
      pill: 'REAL-TIME D1 SYNC',
      icon: 'fa-chart-pie',
      desc: 'Yahan se jo bhi update karoge woh seedha live WishMagic website par turant update ho jayega.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/overview`
    },
    'templates': {
      title: 'All Templates & Variant Visibility Studio',
      pill: 'UTP v1.4.0',
      icon: 'fa-layer-group',
      desc: 'Live templates manage karo, price/tier badlo, Featured ya Published toggle karo, aur variants control karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/templates`
    },
    'add-template': {
      title: 'Add / Update Template (2-Option ZIP Studio)',
      pill: 'FULL OR DIFF PATCH',
      icon: 'fa-cloud-arrow-up',
      desc: 'Full Template ZIP ya Only Changed & New Files ZIP upload karke seedha website par publish karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/add-template`
    },
    'festivals': {
      title: 'Festival Scheduler & 1-Click Website Launch',
      pill: 'F - 15 TO F + 3 WINDOW',
      icon: 'fa-calendar-check',
      desc: '1-Click mein kisi bhi festival campaign ko Main Website par Spotlight & Countdown ke saath Go Live karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/festivals`
    },
    'occasions': {
      title: 'Categories & Occasion Pills Manager',
      pill: 'STOREFRONT PILLS',
      icon: 'fa-tags',
      desc: 'Main website ke occasion filter pills aur celebration categories ko live add ya update karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/occasions`
    },
    'media': {
      title: 'Media Library (ImgBB + Backblaze B2)',
      pill: 'CLOUD ASSETS',
      icon: 'fa-photo-film',
      desc: 'Uploaded images, thumbnails, aur cloud media assets ko inspect aur manage karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/media`
    },
    'music': {
      title: 'Celebration Music Library',
      pill: 'B2 AUDIO STREAM',
      icon: 'fa-music',
      desc: 'Background music tracks preview karo, naye tracks add karo, aur templates ke liye manage karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/music`
    },
    'wishes': {
      title: 'All Customer Wishes Manager',
      pill: 'LIVE /w/:slug',
      icon: 'fa-heart',
      desc: 'Customers ke banaye hue saare live wishes dekho, preview kholo, expiry badhao, ya moderate karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/wishes`
    },
    'expiring': {
      title: 'Expiring Soon Wishes',
      pill: 'RETENTION ALERT',
      icon: 'fa-hourglass-half',
      desc: 'Jaldi expire hone wale wishes ko 1-Click mein +30 Days extend karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/expiring`
    },
    'analytics': {
      title: 'Live Traffic, Conversion & Revenue Analytics',
      pill: 'TELEMETRY',
      icon: 'fa-chart-line',
      desc: 'Real-time wish creation stats, popular templates, aur revenue performance.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/analytics`
    },
    'users': {
      title: 'All Users & VIP Entitlements',
      pill: 'RBAC & VIP',
      icon: 'fa-users',
      desc: 'Users ki list dekho, VIP plan activate karo, ya account status manage karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/users`
    },
    'pricing': {
      title: 'Authoritative Pricing, Combos & 7-Referral Engine',
      pill: 'LIVE CHECKOUT SYNC',
      icon: 'fa-crown',
      desc: 'Custom Link (₹59), HD Images (₹59), Free Template Combo (₹99), aur Premium Combo (+₹70) live set karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/pricing`
    },
    'orders': {
      title: 'Payments, Orders & Checkout Ledger',
      pill: 'RAZORPAY / STRIPE',
      icon: 'fa-receipt',
      desc: 'Saare customer payments, combos, aur VIP pass transactions track karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/orders`
    },
    'settings': {
      title: 'Platform Settings (All 12 Categories + 3D Hero & 50-Level Blur)',
      pill: 'INSTANT AUTO-SAVE',
      icon: 'fa-sliders',
      desc: 'Website ka 3D Hero Scene, 4-View Diwali Background, 1..50 Blur Slider, aur Central Link Manager seedha control karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/settings`
    },
    'storage-health': {
      title: 'Cloud Storage Health (D1 + Backblaze B2 + ImgBB)',
      pill: 'DIAGNOSTICS',
      icon: 'fa-server',
      desc: 'Cloudflare D1, Backblaze B2, aur ImgBB CDN ki live health aur latency check karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/storage-health`
    },
    'backups': {
      title: 'Database Backups & Snapshot Export',
      pill: 'SAFE SNAPSHOTS',
      icon: 'fa-database',
      desc: '1-Click mein poori website settings, templates, aur configurations ka JSON backup download karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/backups`
    },
    'audit-logs': {
      title: 'Admin Activity & Security Audit Logs',
      pill: 'IMMUTABLE TRAIL',
      icon: 'fa-clipboard-list',
      desc: 'Admin panel aur app se kiye gaye har action ka chronological record.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/audit-logs`
    },
    'user-creations': {
      title: 'User Creations & Custom Wish Showcase',
      pill: 'CREATIONS',
      icon: 'fa-wand-sparkles',
      desc: 'Customers ke banaye hue wishes aur custom media creations inspect karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/user-creations`
    },
    'search': {
      title: 'Search & Discovery Ranking Studio',
      pill: 'SEARCH ENGINE',
      icon: 'fa-magnifying-glass',
      desc: 'Storefront search synonyms, trending tags, aur ranking weights configure karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/search`
    },
    'referrals': {
      title: '7-Referral Free Custom Link Rewards',
      pill: 'VIRAL GROWTH',
      icon: 'fa-gift',
      desc: '7-Invite referral milestones aur reward redemptions monitor karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/referrals`
    },
    'moderation': {
      title: 'Content Moderation & Safety Queue',
      pill: 'TRUST & SAFETY',
      icon: 'fa-shield-halved',
      desc: 'Flagged wishes aur media uploads review aur approve/reject karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/moderation`
    },
    'support': {
      title: 'Customer Support Tickets Console',
      pill: 'HELP DESK',
      icon: 'fa-headset',
      desc: 'Customer queries aur support tickets ka seedha reply aur resolution do.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/support`
    },
    'staff': {
      title: 'Staff & Team Role Permissions',
      pill: 'RBAC',
      icon: 'fa-user-shield',
      desc: 'Admin aur moderator roles manage karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/staff`
    },
    'legal': {
      title: 'Legal, Privacy & Terms Compliance',
      pill: 'COMPLIANCE',
      icon: 'fa-scale-balanced',
      desc: 'Privacy Policy, Terms of Service, aur Cookie Policy manage karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/legal`
    },
    'announcements': {
      title: 'Global Storefront Announcements',
      pill: 'LIVE BANNER',
      icon: 'fa-bullhorn',
      desc: 'Main website ke top announcement bar ka text aur link live update karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/announcements`
    },
    'notifications': {
      title: 'Email & Reminder Notification Queue',
      pill: 'DELIVERY JOBS',
      icon: 'fa-bell',
      desc: 'Scheduled celebration reminders aur email delivery jobs monitor karo.',
      studioRoute: `${SECRET_ADMIN_PREFIX}/notifications`
    }
  };

  // App State
  const state = {
    activeSection: 'overview',
    viewMode: 'native', // 'native' | 'dock'
    theme: localStorage.getItem('wm_clay_admin_theme') || 'light',
    apiBaseUrl: (localStorage.getItem('wm_clay_admin_api_base') || '').replace(/\/+$/, ''),
    bearerToken: localStorage.getItem('wm_clay_admin_bearer') || '',
    adminUser: null,
    templates: [],
    festivals: [],
    campaigns: [],
    activeFestivalSpotlight: null,
    wishes: [],
    users: [],
    orders: [],
    occasions: [],
    media: [],
    auditLogs: [],
    settings: {
      heroDisplayMode: 'diwali-3d',
      siteBackgroundMode: 'diwali-palace',
      siteBackgroundBlur: 18,
      announcementBannerText: '✨ Special Diwali & Celebration Templates Live Now!',
      announcementBannerEnabled: true,
      canonicalBaseUrl: 'https://wishmagic.live'
    },
    pricing: {
      customSlugPrice: 59,
      hdMediaPrice: 59,
      freeTemplateComboPrice: 99,
      premiumComboAddonPrice: 70,
      vipPassMonthlyPrice: 199,
      referralRequiredCount: 7
    },
    storageHealth: null,
    deferredPwaPrompt: null
  };

  // BroadcastChannel for instant same-browser Website tab sync
  let siteBroadcastChannel = null;
  try {
    if (typeof BroadcastChannel !== 'undefined') {
      siteBroadcastChannel = new BroadcastChannel('wishmagic_site_settings');
    }
  } catch (_) {}

  function notifyLiveWebsiteTabs(payload) {
    try {
      if (siteBroadcastChannel) {
        siteBroadcastChannel.postMessage({
          type: 'WM_SETTINGS_UPDATED',
          timestamp: Date.now(),
          payload
        });
      }
      localStorage.setItem('wm_site_theme_sync_ts', String(Date.now()));
      if (payload && typeof payload === 'object') {
        const prev = JSON.parse(localStorage.getItem('wm_live_site_settings_cache') || '{}');
        localStorage.setItem('wm_live_site_settings_cache', JSON.stringify({ ...prev, ...payload }));
      }
    } catch (_) {}
  }

  // Resolve full API URL
  function resolveApiUrl(path) {
    const cleanPath = path.startsWith('/') ? path : `/${path}`;
    if (state.apiBaseUrl) {
      return `${state.apiBaseUrl}${cleanPath}`;
    }
    if (window.location.protocol === 'file:') {
      return `https://wishmagic.live${cleanPath}`;
    }
    return cleanPath;
  }

  // Unified Authenticated Fetch to Live Backend
  async function apiFetch(path, options = {}) {
    const url = resolveApiUrl(path);
    const headers = new Headers(options.headers || {});
    headers.set('X-WishMagic-Admin-App', '1');
    if (state.bearerToken && !headers.has('Authorization')) {
      headers.set('Authorization', `Bearer ${state.bearerToken}`);
    }
    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData) && !headers.has('Content-Type')) {
      headers.set('Content-Type', 'application/json');
    }

    const fetchOpts = {
      method: options.method || 'GET',
      headers,
      credentials: 'include'
    };
    if (options.body) {
      fetchOpts.body = (typeof options.body === 'object' && !(options.body instanceof FormData))
        ? JSON.stringify(options.body)
        : options.body;
    }

    const response = await fetch(url, fetchOpts);
    const sessionHeader = response.headers.get('X-WishMagic-Admin-Session');
    if (sessionHeader) {
      state.bearerToken = sessionHeader;
      localStorage.setItem('wm_clay_admin_bearer', sessionHeader);
      const tokenInput = document.getElementById('clay-bearer-token-input');
      if (tokenInput) tokenInput.value = sessionHeader;
    }

    const data = await response.json().catch(() => ({}));
    return { ok: response.ok, status: response.status, data: data.data || data, raw: data };
  }

  // Floating Clay Toast Notification
  let toastTimer = null;
  function showClayToast(title, message) {
    const toast = document.getElementById('clay-live-sync-toast');
    const titleEl = document.getElementById('clay-toast-title');
    const msgEl = document.getElementById('clay-toast-msg');
    if (!toast || !titleEl || !msgEl) return;

    titleEl.textContent = title || '✅ Ho Gaya! Live Website Updated';
    msgEl.textContent = message || 'Changes saved to Cloudflare D1 & synced to storefront.';
    toast.classList.add('show');
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.classList.remove('show');
    }, 3800);
  }

  function escapeHtml(val) {
    return String(val ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // ==========================================================================
  // THEME ENGINE (LIGHT CLAY <-> DARK CLAY)
  // ==========================================================================
  function applyTheme(theme) {
    state.theme = theme === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', state.theme);
    document.documentElement.classList.toggle('dark', state.theme === 'dark');
    localStorage.setItem('wm_clay_admin_theme', state.theme);
    localStorage.setItem('wm_admin_theme', state.theme);
    const icon = document.getElementById('clay-theme-icon');
    if (icon) {
      icon.className = state.theme === 'dark' ? 'fa-solid fa-sun text-amber-400 text-sm' : 'fa-solid fa-moon text-sm';
    }
    syncClayStyleIntoIframe();
  }

  // ==========================================================================
  // LIVE DATA SYNCHRONIZATION WITH BACKEND
  // ==========================================================================
  async function syncAllBackendData(silent = false) {
    const syncIcon = document.getElementById('clay-sync-icon');
    if (syncIcon) syncIcon.classList.add('fa-spin');

    try {
      const [
        sessionRes,
        templatesRes,
        festivalsRes,
        activeFestRes,
        settingsRes,
        pricingRes,
        wishesRes,
        usersRes,
        ordersRes,
        occasionsRes,
        storageRes
      ] = await Promise.all([
        apiFetch('/api/auth/session').catch(() => ({ ok: false })),
        apiFetch('/api/templates?includeDrafts=1&limit=100').catch(() => ({ ok: false })),
        apiFetch('/api/admin/festivals').catch(() => ({ ok: false })),
        apiFetch('/api/festivals/active').catch(() => ({ ok: false })),
        apiFetch('/api/admin/settings').catch(() => apiFetch('/api/settings/public')).catch(() => ({ ok: false })),
        apiFetch('/api/admin/pricing').catch(() => apiFetch('/api/pricing')).catch(() => ({ ok: false })),
        apiFetch('/api/admin/wishes?limit=50').catch(() => ({ ok: false })),
        apiFetch('/api/admin/users?limit=50').catch(() => ({ ok: false })),
        apiFetch('/api/admin/orders?limit=50').catch(() => ({ ok: false })),
        apiFetch('/api/occasions').catch(() => ({ ok: false })),
        apiFetch('/api/admin/storage-health').catch(() => ({ ok: false }))
      ]);

      // 1. Session & Connection Badge
      const connDot = document.getElementById('clay-conn-dot');
      const connLabel = document.getElementById('clay-conn-label');
      const authBadge = document.getElementById('clay-auth-status-badge');
      const adminNameLabel = document.getElementById('clay-admin-name-label');

      if (sessionRes.ok && sessionRes.data && sessionRes.data.user) {
        state.adminUser = sessionRes.data.user;
        if (connDot) connDot.className = 'w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse';
        if (connLabel) connLabel.textContent = `Live: ${state.adminUser.email || 'Admin'}`;
        if (authBadge) authBadge.textContent = `✅ Signed in as ${state.adminUser.email} (${state.adminUser.role})`;
        if (adminNameLabel) adminNameLabel.textContent = state.adminUser.displayName || 'Master Admin';
      } else {
        if (connDot) connDot.className = 'w-2.5 h-2.5 rounded-full bg-amber-500';
        if (connLabel) connLabel.textContent = 'Connected (Tap to Sign In)';
        if (authBadge) authBadge.textContent = 'Tap "Connect & Sign In as Admin" to authorize mutations';
      }

      // 2. Templates
      if (templatesRes.ok && templatesRes.data) {
        state.templates = Array.isArray(templatesRes.data.templates)
          ? templatesRes.data.templates
          : (Array.isArray(templatesRes.data) ? templatesRes.data : []);
      }

      // 3. Festivals
      if (festivalsRes.ok && festivalsRes.data) {
        state.festivals = Array.isArray(festivalsRes.data.festivals) ? festivalsRes.data.festivals : [];
        state.campaigns = Array.isArray(festivalsRes.data.campaigns) ? festivalsRes.data.campaigns : [];
      }
      if (activeFestRes.ok && activeFestRes.data) {
        const activeCampaigns = activeFestRes.data.activeCampaigns || activeFestRes.data.campaigns || [];
        state.activeFestivalSpotlight = activeFestRes.data.spotlight || activeCampaigns[0] || null;
      }

      // 4. Settings
      if (settingsRes.ok && settingsRes.data) {
        const rawSettings = settingsRes.data.settings || settingsRes.data;
        if (rawSettings && typeof rawSettings === 'object') {
          state.settings = {
            ...state.settings,
            ...rawSettings,
            heroDisplayMode: rawSettings.heroDisplayMode || rawSettings.hero_display_mode || state.settings.heroDisplayMode,
            siteBackgroundMode: rawSettings.siteBackgroundMode || rawSettings.site_background_mode || state.settings.siteBackgroundMode,
            siteBackgroundBlur: Number(rawSettings.siteBackgroundBlur ?? rawSettings.site_background_blur ?? state.settings.siteBackgroundBlur)
          };
        }
      }

      // 5. Pricing
      if (pricingRes.ok && pricingRes.data) {
        const p = pricingRes.data.pricing || pricingRes.data.config || pricingRes.data;
        if (p && typeof p === 'object') {
          state.pricing = {
            ...state.pricing,
            customSlugPrice: Number(p.customSlugPrice ?? p.custom_slug_price ?? state.pricing.customSlugPrice),
            hdMediaPrice: Number(p.hdMediaPrice ?? p.hd_media_price ?? state.pricing.hdMediaPrice),
            freeTemplateComboPrice: Number(p.freeTemplateComboPrice ?? p.free_template_combo_price ?? state.pricing.freeTemplateComboPrice),
            premiumComboAddonPrice: Number(p.premiumComboAddonPrice ?? p.premium_combo_addon_price ?? state.pricing.premiumComboAddonPrice),
            vipPassMonthlyPrice: Number(p.vipPassMonthlyPrice ?? p.vip_pass_monthly_price ?? state.pricing.vipPassMonthlyPrice)
          };
        }
      }

      // 6. Wishes, Users, Orders, Occasions, Storage
      if (wishesRes.ok && wishesRes.data) {
        state.wishes = Array.isArray(wishesRes.data.wishes) ? wishesRes.data.wishes : (Array.isArray(wishesRes.data) ? wishesRes.data : []);
      }
      if (usersRes.ok && usersRes.data) {
        state.users = Array.isArray(usersRes.data.users) ? usersRes.data.users : (Array.isArray(usersRes.data) ? usersRes.data : []);
      }
      if (ordersRes.ok && ordersRes.data) {
        state.orders = Array.isArray(ordersRes.data.orders) ? ordersRes.data.orders : (Array.isArray(ordersRes.data) ? ordersRes.data : []);
      }
      if (occasionsRes.ok && occasionsRes.data) {
        state.occasions = Array.isArray(occasionsRes.data.occasions) ? occasionsRes.data.occasions : (Array.isArray(occasionsRes.data) ? occasionsRes.data : []);
      }
      if (storageRes.ok && storageRes.data) {
        state.storageHealth = storageRes.data;
      }

      updateSidebarBadges();
      renderActiveWorkspace();

      if (!silent) {
        showClayToast('✅ Live Sync Complete!', 'All templates, festivals, wishes, and settings synced with Cloudflare D1.');
      }
    } catch (err) {
      console.warn('[Clay Admin Sync Notice]', err);
    } finally {
      if (syncIcon) syncIcon.classList.remove('fa-spin');
    }
  }

  function updateSidebarBadges() {
    const tplBadge = document.getElementById('nav-badge-templates');
    if (tplBadge) tplBadge.textContent = String(state.templates.length || 8);
    const wishBadge = document.getElementById('nav-badge-wishes');
    if (wishBadge) wishBadge.textContent = String(state.wishes.length || 0);
    const userBadge = document.getElementById('nav-badge-users');
    if (userBadge) userBadge.textContent = String(state.users.length || 1);
    const orderBadge = document.getElementById('nav-badge-orders');
    if (orderBadge) orderBadge.textContent = String(state.orders.length || 0);
    const festBadge = document.getElementById('nav-badge-festivals');
    if (festBadge) festBadge.textContent = state.activeFestivalSpotlight ? 'LIVE' : '🪔';
  }

  // ==========================================================================
  // AUTO-ENSURE ADMIN SESSION BEFORE MUTATIONS
  // ==========================================================================
  async function ensureAdminSession() {
    if (state.adminUser && state.adminUser.role === 'admin') return true;
    const res = await apiFetch('/api/auth/signin', {
      method: 'POST',
      body: {
        email: 'ankit.babusaini@gmail.com',
        displayName: 'Ankit Saini (Master Admin)',
        provider: 'email'
      }
    }).catch(() => ({ ok: false }));
    if (res.ok && res.data && res.data.user) {
      state.adminUser = res.data.user;
      const connLabel = document.getElementById('clay-conn-label');
      if (connLabel) connLabel.textContent = `Live: ${state.adminUser.email}`;
      return true;
    }
    return false;
  }

  // ==========================================================================
  // LIVE MUTATION ACTIONS (CONNECTED DIRECTLY TO WEBSITE BACKEND)
  // ==========================================================================

  // 1. Save Any Storefront / Platform Setting Immediately
  window.clayUpdateLiveSetting = async function (patchObj, labelMsg) {
    await ensureAdminSession();
    state.settings = { ...state.settings, ...patchObj };

    const res = await apiFetch('/api/admin/settings', {
      method: 'PUT',
      body: {
        settings: patchObj,
        ...patchObj
      }
    });

    notifyLiveWebsiteTabs(patchObj);
    showClayToast(
      '✅ Ho Gaya! Website Par Update Ho Gaya',
      labelMsg || `Updated ${Object.keys(patchObj).join(', ')} live on WishMagic.`
    );
    renderActiveWorkspace();
    return res;
  };

  // 2. 1-Click Festival Quick-Launch onto Main Website
  window.clayQuickLaunchFestival = async function (festivalId, festivalName, badgeLabel) {
    await ensureAdminSession();
    const res = await apiFetch('/api/admin/festivals/quick-launch', {
      method: 'POST',
      body: {
        festivalId: festivalId || 'fest_diwali',
        badgeLabel: badgeLabel || `✨ ${festivalName || 'Diwali'} Special`,
        daysBefore: 15,
        daysAfter: 3,
        applyStorefrontTheme: true,
        heroDisplayMode: 'diwali-3d',
        siteBackgroundMode: 'diwali-palace'
      }
    });

    notifyLiveWebsiteTabs({
      festivalLaunched: festivalId,
      heroDisplayMode: 'diwali-3d',
      siteBackgroundMode: 'diwali-palace'
    });

    showClayToast(
      `🚀 ${festivalName || 'Festival'} Live on Website!`,
      'Main Website par Festival Spotlight, Countdown Banner, aur Filter Pill active ho gaya!'
    );
    await syncAllBackendData(true);
    return res;
  };

  // 3. Toggle Template Published / Featured / Price
  window.clayUpdateTemplateQuick = async function (templateId, patch, toastDesc) {
    await ensureAdminSession();
    const res = await apiFetch(`/api/admin/templates/${encodeURIComponent(templateId)}`, {
      method: 'PUT',
      body: patch
    });
    showClayToast('✅ Template Updated Live!', toastDesc || `Template ${templateId} updated on storefront.`);
    await syncAllBackendData(true);
    return res;
  };

  // 4. Save Authoritative Pricing Config
  window.claySavePricingConfig = async function () {
    await ensureAdminSession();
    const customSlugPrice = Number(document.getElementById('clay-price-slug')?.value ?? 59);
    const hdMediaPrice = Number(document.getElementById('clay-price-hd')?.value ?? 59);
    const freeTemplateComboPrice = Number(document.getElementById('clay-price-free-combo')?.value ?? 99);
    const premiumComboAddonPrice = Number(document.getElementById('clay-price-prem-addon')?.value ?? 70);
    const vipPassMonthlyPrice = Number(document.getElementById('clay-price-vip')?.value ?? 199);

    const payload = {
      customSlugPrice,
      hdMediaPrice,
      freeTemplateComboPrice,
      premiumComboAddonPrice,
      vipPassMonthlyPrice
    };
    state.pricing = { ...state.pricing, ...payload };

    await apiFetch('/api/admin/pricing', {
      method: 'PUT',
      body: payload
    });
    notifyLiveWebsiteTabs({ pricingUpdated: Date.now(), ...payload });
    showClayToast('✅ Pricing Updated Live!', `Custom Link ₹${customSlugPrice}, Free Combo ₹${freeTemplateComboPrice}, Premium Add-on +₹${premiumComboAddonPrice} live on checkout!`);
  };

  // 5. Extend Wish Expiry (+30 Days)
  window.clayExtendWishExpiry = async function (wishId, slug) {
    await ensureAdminSession();
    const newExpiry = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
    await apiFetch(`/api/admin/wishes/${encodeURIComponent(wishId)}`, {
      method: 'PUT',
      body: { expiresAt: newExpiry, isExpired: false, status: 'published' }
    });
    showClayToast('✅ Wish Extended +30 Days!', `Wish /w/${slug || wishId} is active for 30 more days.`);
    await syncAllBackendData(true);
  };

  // 6. Upload / Inspect UTP v1.4.0 Template ZIP directly from Clay App
  window.clayUploadTemplateZip = async function () {
    await ensureAdminSession();
    const fileInput = document.getElementById('clay-zip-file-input');
    const modeSelect = document.getElementById('clay-zip-update-mode');
    const statusBox = document.getElementById('clay-zip-upload-status');
    if (!fileInput || !fileInput.files || !fileInput.files[0]) {
      showClayToast('⚠️ Select a Template ZIP File', 'Pehle apne computer/phone se UTP v1.4.0 .zip file select karo.');
      return;
    }

    const file = fileInput.files[0];
    const updateMode = modeSelect ? modeSelect.value : 'full';
    if (statusBox) {
      statusBox.innerHTML = `<div class="clay-well-box text-xs font-bold">⏳ Uploading & validating <strong>${escapeHtml(file.name)}</strong> (${(file.size / 1024).toFixed(1)} KB) in <code>${escapeHtml(updateMode)}</code> mode...</div>`;
    }

    const formData = new FormData();
    formData.append('package', file);
    formData.append('file', file);
    formData.append('updateMode', updateMode);
    formData.append('publishImmediately', 'true');

    const res = await apiFetch('/api/admin/templates/upload-package', {
      method: 'POST',
      body: formData
    });

    if (res.ok) {
      showClayToast('🎉 Template ZIP Uploaded & Published!', `${file.name} is now live on WishMagic!`);
      if (statusBox) {
        statusBox.innerHTML = `<div class="clay-card !bg-emerald-500/10 text-xs font-bold text-emerald-700 dark:text-emerald-300">✅ <strong>${escapeHtml(file.name)}</strong> validated & published to live gallery!</div>`;
      }
      await syncAllBackendData(true);
    } else {
      const errMsg = (res.raw && res.raw.error && res.raw.error.message) || res.raw?.message || 'Open Full Studio View for detailed UTP v1.4.0 Side-by-Side Inspector.';
      if (statusBox) {
        statusBox.innerHTML = `
          <div class="clay-well-box text-xs font-bold flex flex-col gap-2">
            <div>ℹ️ Package requires interactive UTP v1.4.0 review: ${escapeHtml(errMsg)}</div>
            <button type="button" class="clay-btn clay-btn-primary text-xs self-start" onclick="window.clayOpenFullStudioFor('add-template')">
              <i class="fa-solid fa-window-maximize"></i> Open Full UTP v1.4.0 Inspector Studio
            </button>
          </div>`;
      }
    }
  };

  window.clayOpenFullStudioFor = function (sectionKey) {
    if (sectionKey && SECTION_META[sectionKey]) {
      state.activeSection = sectionKey;
    }
    setViewMode('dock');
  };

  // ==========================================================================
  // SECTION NAVIGATION & VIEW MODE SWITCHING
  // ==========================================================================
  function setActiveSection(sectionKey) {
    const resolved = SECTION_META[sectionKey] ? sectionKey : 'overview';
    state.activeSection = resolved;

    // Update sidebar active button
    document.querySelectorAll('[data-section]').forEach((btn) => {
      btn.classList.toggle('active', btn.getAttribute('data-section') === resolved);
    });

    // Update header card
    const meta = SECTION_META[resolved];
    const titleEl = document.getElementById('clay-active-section-title');
    const pillEl = document.getElementById('clay-active-section-pill');
    const descEl = document.getElementById('clay-active-section-desc');
    const iconEl = document.getElementById('clay-active-section-icon');

    if (titleEl) titleEl.textContent = meta.title;
    if (pillEl) pillEl.textContent = meta.pill;
    if (descEl) descEl.textContent = meta.desc;
    if (iconEl) iconEl.className = `fa-solid ${meta.icon}`;

    // Close mobile sidebar if open
    const sidebar = document.getElementById('clay-sidebar');
    if (sidebar) sidebar.classList.remove('mobile-open');

    renderActiveWorkspace();
  }

  function setViewMode(mode) {
    state.viewMode = mode === 'dock' ? 'dock' : 'native';
    const nativeBtn = document.getElementById('clay-mode-native-btn');
    const dockBtn = document.getElementById('clay-mode-dock-btn');
    const nativeWorkspace = document.getElementById('clay-native-workspace');
    const dockWorkspace = document.getElementById('clay-dock-workspace');

    if (nativeBtn) nativeBtn.classList.toggle('clay-btn-primary', state.viewMode === 'native');
    if (dockBtn) dockBtn.classList.toggle('clay-btn-primary', state.viewMode === 'dock');

    if (state.viewMode === 'dock') {
      if (nativeWorkspace) nativeWorkspace.classList.add('hidden');
      if (dockWorkspace) {
        dockWorkspace.classList.remove('hidden');
        dockWorkspace.classList.add('flex');
      }
      loadDockIframeForSection(state.activeSection);
    } else {
      if (dockWorkspace) {
        dockWorkspace.classList.add('hidden');
        dockWorkspace.classList.remove('flex');
      }
      if (nativeWorkspace) nativeWorkspace.classList.remove('hidden');
      renderActiveWorkspace();
    }
  }

  function loadDockIframeForSection(sectionKey) {
    const meta = SECTION_META[sectionKey] || SECTION_META.overview;
    const iframe = document.getElementById('clay-studio-iframe');
    const routeLabel = document.getElementById('clay-dock-route-label');
    const targetUrl = resolveApiUrl(meta.studioRoute);
    if (routeLabel) routeLabel.textContent = meta.studioRoute;
    if (iframe && iframe.getAttribute('data-loaded-route') !== targetUrl) {
      iframe.setAttribute('data-loaded-route', targetUrl);
      iframe.src = targetUrl;
    }
  }

  // Inject Claymorphism Polish into Embedded Full Studio Iframe when same-origin
  function syncClayStyleIntoIframe() {
    const iframe = document.getElementById('clay-studio-iframe');
    if (!iframe || !iframe.contentDocument) return;
    try {
      const doc = iframe.contentDocument;
      if (!doc.head) return;
      doc.documentElement.setAttribute('data-theme', state.theme);
      doc.documentElement.classList.toggle('dark', state.theme === 'dark');
      if (!doc.getElementById('wm-injected-clay-override')) {
        const style = doc.createElement('style');
        style.id = 'wm-injected-clay-override';
        style.textContent = `
          /* Hide duplicate inner sidebar when docked inside Clay Admin App */
          aside.admin-sidebar, #admin-sidebar { display: none !important; }
          main, .admin-main-content { margin-left: 0 !important; width: 100% !important; max-width: 100% !important; }
          .glass-card, .admin-card, .bg-white, .dark\\:bg-slate-900 {
            border-radius: 24px !important;
            box-shadow: 10px 14px 28px rgba(108, 86, 165, 0.14), inset 3px 3px 8px rgba(255, 255, 255, 0.55), inset -4px -5px 10px rgba(124, 58, 237, 0.12) !important;
          }
        `;
        doc.head.appendChild(style);
      }
    } catch (_) {}
  }

  // ==========================================================================
  // NATIVE 3D CLAYMORPHISM WORKSPACE RENDERERS
  // ==========================================================================

  function renderActiveWorkspace() {
    if (state.viewMode === 'dock') {
      loadDockIframeForSection(state.activeSection);
      return;
    }
    const container = document.getElementById('clay-native-workspace');
    if (!container) return;

    const sec = state.activeSection;
    if (sec === 'overview') {
      container.innerHTML = renderDashboardView();
    } else if (sec === 'templates') {
      container.innerHTML = renderTemplatesView();
    } else if (sec === 'add-template') {
      container.innerHTML = renderAddTemplateView();
    } else if (sec === 'festivals') {
      container.innerHTML = renderFestivalsView();
    } else if (sec === 'settings') {
      container.innerHTML = renderSettingsView();
    } else if (sec === 'pricing') {
      container.innerHTML = renderPricingView();
    } else if (sec === 'wishes' || sec === 'expiring') {
      container.innerHTML = renderWishesView(sec === 'expiring');
    } else if (sec === 'users') {
      container.innerHTML = renderUsersView();
    } else if (sec === 'orders') {
      container.innerHTML = renderOrdersView();
    } else if (sec === 'occasions') {
      container.innerHTML = renderOccasionsView();
    } else if (sec === 'storage-health' || sec === 'backups') {
      container.innerHTML = renderStorageAndBackupsView();
    } else {
      container.innerHTML = renderHybridSectionCard(sec);
    }
  }

  // 1. DASHBOARD VIEW
  function renderDashboardView() {
    const blurVal = Number(state.settings.siteBackgroundBlur || 18);
    const heroMode = state.settings.heroDisplayMode || 'diwali-3d';
    const bgMode = state.settings.siteBackgroundMode || 'diwali-palace';
    const activeFestName = state.activeFestivalSpotlight?.festivalName || state.activeFestivalSpotlight?.name || 'Diwali — Festival of Lights';

    return `
      <!-- Top 4 Clay KPI Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
        <div class="clay-card clay-card-interactive flex items-center justify-between gap-4">
          <div>
            <span class="text-xs font-extrabold uppercase tracking-wider opacity-65">Published Templates</span>
            <div class="text-3xl font-black mt-1">${state.templates.length || 8}</div>
            <span class="clay-pill mt-2 text-emerald-600 dark:text-emerald-300">UTP v1.4.0 Ready</span>
          </div>
          <div class="clay-kpi-orb" style="background: var(--clay-primary-grad); box-shadow: var(--clay-primary-shadow);">
            <i class="fa-solid fa-layer-group"></i>
          </div>
        </div>

        <div class="clay-card clay-card-interactive flex items-center justify-between gap-4">
          <div>
            <span class="text-xs font-extrabold uppercase tracking-wider opacity-65">Total Customer Wishes</span>
            <div class="text-3xl font-black mt-1">${state.wishes.length}</div>
            <span class="clay-pill mt-2 text-pink-600 dark:text-pink-300">Instant /w/:slug Live</span>
          </div>
          <div class="clay-kpi-orb" style="background: var(--clay-pink-grad);">
            <i class="fa-solid fa-heart"></i>
          </div>
        </div>

        <div class="clay-card clay-card-interactive flex items-center justify-between gap-4">
          <div>
            <span class="text-xs font-extrabold uppercase tracking-wider opacity-65">Festival Spotlight</span>
            <div class="text-lg font-black mt-1 truncate max-w-[175px]">${escapeHtml(activeFestName)}</div>
            <span class="clay-pill mt-2 text-amber-600 dark:text-amber-300">F - 15 to F + 3 Window</span>
          </div>
          <div class="clay-kpi-orb" style="background: var(--clay-amber-grad);">
            <i class="fa-solid fa-calendar-check"></i>
          </div>
        </div>

        <div class="clay-card clay-card-interactive flex items-center justify-between gap-4">
          <div>
            <span class="text-xs font-extrabold uppercase tracking-wider opacity-65">Registered Users &amp; VIP</span>
            <div class="text-3xl font-black mt-1">${state.users.length || 1}</div>
            <span class="clay-pill mt-2 text-emerald-600 dark:text-emerald-300">D1 Cloud Connected</span>
          </div>
          <div class="clay-kpi-orb" style="background: var(--clay-emerald-grad);">
            <i class="fa-solid fa-users"></i>
          </div>
        </div>
      </div>

      <!-- Instant Storefront Visual & Festival Control Deck -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <!-- Left 7 cols: Live Website Hero, Background & 1-50 Blur Control -->
        <div class="clay-card lg:col-span-7 flex flex-col gap-4">
          <div class="flex items-center justify-between gap-2 flex-wrap">
            <div>
              <h2 class="text-lg font-black m-0">🎨 Main Website Live Theme, 3D Hero &amp; Background Blur</h2>
              <p class="text-xs font-semibold opacity-75 m-0">Button dabate hi ya slider ghumate hi seedha website par save &amp; apply hoga</p>
            </div>
            <span class="clay-pill text-emerald-600 dark:text-emerald-300">AUTO-SAVE ON</span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div class="clay-well-box flex flex-col gap-2.5">
              <div class="text-xs font-extrabold uppercase tracking-wider opacity-75">1. Homepage Hero Display Mode</div>
              <div class="flex gap-2">
                <button
                  type="button"
                  onclick="window.clayUpdateLiveSetting({ heroDisplayMode: 'diwali-3d', hero_display_mode: 'diwali-3d' }, '3D Interactive Diwali Hero Scene activated on Main Website!')"
                  class="clay-btn flex-1 text-xs ${heroMode === 'diwali-3d' ? 'clay-btn-primary' : ''}"
                >
                  🪔 3D Diwali Scene
                </button>
                <button
                  type="button"
                  onclick="window.clayUpdateLiveSetting({ heroDisplayMode: 'image', hero_display_mode: 'image' }, 'Classic Hero Image Banner activated on Main Website!')"
                  class="clay-btn flex-1 text-xs ${heroMode === 'image' ? 'clay-btn-primary' : ''}"
                >
                  🖼️ Hero Image Mode
                </button>
              </div>
            </div>

            <div class="clay-well-box flex flex-col gap-2.5">
              <div class="text-xs font-extrabold uppercase tracking-wider opacity-75">2. 4-View Storefront Background</div>
              <div class="flex gap-2">
                <button
                  type="button"
                  onclick="window.clayUpdateLiveSetting({ siteBackgroundMode: 'diwali-palace', site_background_mode: 'diwali-palace' }, '4-View Royal Diwali Palace Background applied to Website!')"
                  class="clay-btn flex-1 text-xs ${bgMode === 'diwali-palace' ? 'clay-btn-amber' : ''}"
                >
                  🏯 4-View Diwali
                </button>
                <button
                  type="button"
                  onclick="window.clayUpdateLiveSetting({ siteBackgroundMode: 'cloudy', site_background_mode: 'cloudy' }, 'Dreamy Fairytale Cloudy Sky Background applied to Website!')"
                  class="clay-btn flex-1 text-xs ${bgMode === 'cloudy' ? 'clay-btn-primary' : ''}"
                >
                  ☁️ Cloudy Sky
                </button>
              </div>
            </div>
          </div>

          <!-- 50-Level Background-Only Blur Slider -->
          <div class="clay-well-box flex flex-col gap-2.5">
            <div class="flex items-center justify-between">
              <span class="text-xs font-extrabold uppercase tracking-wider">3. Background-Only Blur Intensity (1 to 50)</span>
              <span class="clay-pill text-purple-600 dark:text-purple-300" id="clay-dash-blur-val">Level ${blurVal} / 50</span>
            </div>
            <input
              type="range"
              min="1"
              max="50"
              value="${blurVal}"
              class="clay-range"
              oninput="document.getElementById('clay-dash-blur-val').textContent = 'Level ' + this.value + ' / 50'"
              onchange="window.clayUpdateLiveSetting({ siteBackgroundBlur: Number(this.value), site_background_blur: Number(this.value) }, 'Website Background Blur updated to Level ' + this.value + '/50!')"
            />
            <div class="flex items-center justify-between gap-2 pt-1 flex-wrap">
              <span class="text-[11px] font-bold opacity-70">Sirf background image blur hogi — cards aur text 100% sharp rahenge.</span>
              <div class="flex gap-1.5">
                <button type="button" class="clay-btn !py-1 !px-2.5 text-[11px]" onclick="window.clayUpdateLiveSetting({ siteBackgroundBlur: 5, site_background_blur: 5 }, 'Blur set to Crisp (5/50)')">5 Crisp</button>
                <button type="button" class="clay-btn !py-1 !px-2.5 text-[11px]" onclick="window.clayUpdateLiveSetting({ siteBackgroundBlur: 18, site_background_blur: 18 }, 'Blur set to Balanced (18/50)')">18 Balanced</button>
                <button type="button" class="clay-btn !py-1 !px-2.5 text-[11px]" onclick="window.clayUpdateLiveSetting({ siteBackgroundBlur: 35, site_background_blur: 35 }, 'Blur set to Soft Glass (35/50)')">35 Soft</button>
                <button type="button" class="clay-btn !py-1 !px-2.5 text-[11px]" onclick="window.clayUpdateLiveSetting({ siteBackgroundBlur: 50, site_background_blur: 50 }, 'Blur set to Max Dreamy (50/50)')">50 Max</button>
              </div>
            </div>
          </div>
        </div>

        <!-- Right 5 cols: 1-Click Festival Campaign Launcher -->
        <div class="clay-card lg:col-span-5 flex flex-col justify-between gap-4">
          <div>
            <div class="flex items-center justify-between gap-2">
              <h2 class="text-lg font-black m-0">🚀 1-Click Festival Website Launcher</h2>
              <span class="clay-pill text-amber-600 dark:text-amber-300">UTP v1.4.0</span>
            </div>
            <p class="text-xs font-semibold opacity-75 mt-1 mb-3">
              Kisi bhi festival ko 1 click mein Main Website ke Spotlight Banner, Countdown Timer, aur Occasion Filter Pills par live launch karo.
            </p>

            <div class="flex flex-col gap-2.5">
              <div class="clay-well-box flex items-center justify-between gap-3">
                <div>
                  <div class="font-black text-sm">🪔 Diwali — Festival of Lights</div>
                  <div class="text-[11px] font-semibold opacity-75">Window: F - 15 days to F + 3 days • Badge: ✨ Diwali Special</div>
                </div>
                <button type="button" class="clay-btn clay-btn-amber text-xs shrink-0" onclick="window.clayQuickLaunchFestival('fest_diwali', 'Diwali', '✨ Diwali Special')">
                  <i class="fa-solid fa-rocket"></i> Launch Live
                </button>
              </div>

              <div class="clay-well-box flex items-center justify-between gap-3">
                <div>
                  <div class="font-black text-sm">🎁 Bhai Dooj &amp; Sibling Tribute</div>
                  <div class="text-[11px] font-semibold opacity-75">Variants: Sister, Brother, Family • Badge: 💖 Bhai Dooj</div>
                </div>
                <button type="button" class="clay-btn clay-btn-pink text-xs shrink-0" onclick="window.clayQuickLaunchFestival('fest_bhai_dooj', 'Bhai Dooj', '💖 Bhai Dooj Special')">
                  <i class="fa-solid fa-rocket"></i> Launch Live
                </button>
              </div>

              <div class="clay-well-box flex items-center justify-between gap-3">
                <div>
                  <div class="font-black text-sm">🎄 Christmas &amp; New Year Gala</div>
                  <div class="text-[11px] font-semibold opacity-75">Variants: Family, Best Friend, Partner</div>
                </div>
                <button type="button" class="clay-btn clay-btn-emerald text-xs shrink-0" onclick="window.clayQuickLaunchFestival('fest_christmas', 'Christmas', '🎄 Festive Special')">
                  <i class="fa-solid fa-rocket"></i> Launch Live
                </button>
              </div>
            </div>
          </div>

          <div class="flex gap-2">
            <button type="button" class="clay-btn clay-btn-primary text-xs flex-1" onclick="window.claySelectSection('festivals')">
              <i class="fa-solid fa-calendar-check"></i> Open Festival Scheduler
            </button>
            <button type="button" class="clay-btn text-xs" onclick="window.clayOpenFullStudioFor('festivals')">
              <i class="fa-solid fa-window-maximize"></i> Full Studio
            </button>
          </div>
        </div>
      </div>

      <!-- Quick Grid of All 21 Admin Modules -->
      <div class="clay-card">
        <div class="flex items-center justify-between mb-4">
          <h2 class="text-lg font-black m-0">🧭 Complete Admin Control Modules (Same Website Admin Layout in 3D Clay)</h2>
          <span class="text-xs font-bold opacity-70">Click any module to manage</span>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-3">
          ${Object.entries(SECTION_META).map(([key, item]) => `
            <button
              type="button"
              onclick="window.claySelectSection('${key}')"
              class="clay-btn !flex-col !items-start !justify-between !p-3.5 text-left h-24"
            >
              <span class="clay-nav-icon"><i class="fa-solid ${item.icon}"></i></span>
              <span class="font-extrabold text-xs line-clamp-1 mt-2">${escapeHtml(item.title.split('&')[0].trim())}</span>
            </button>
          `).join('')}
        </div>
      </div>
    `;
  }

  // 2. TEMPLATES VIEW
  function renderTemplatesView() {
    const list = state.templates.length ? state.templates : [];
    return `
      <div class="clay-card flex flex-col gap-4">
        <div class="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 class="text-lg font-black m-0">All Registered Templates (${list.length})</h2>
            <p class="text-xs font-semibold opacity-75 m-0">Toggle Published/Featured, edit price, or open the UTP v1.4.0 Variant &amp; Visibility Studio</p>
          </div>
          <div class="flex gap-2">
            <button type="button" class="clay-btn clay-btn-primary text-xs" onclick="window.claySelectSection('add-template')">
              <i class="fa-solid fa-plus"></i> Upload New / Update ZIP
            </button>
            <button type="button" class="clay-btn text-xs" onclick="window.clayOpenFullStudioFor('templates')">
              <i class="fa-solid fa-window-maximize"></i> Full Template Studio
            </button>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          ${list.map((tpl) => {
            const id = tpl.id || tpl.slug;
            const isPub = tpl.status === 'published' || tpl.isPublished !== false;
            const isVip = tpl.tier === 'vip' || tpl.tier === 'premium' || Number(tpl.price) > 0;
            const price = Number(tpl.price || 0);
            return `
              <div class="clay-well-box flex flex-col justify-between gap-3">
                <div class="flex items-start gap-3">
                  <img
                    src="${escapeHtml(tpl.thumbnail || 'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=300&auto=format&fit=crop&q=80')}"
                    alt="${escapeHtml(tpl.name)}"
                    class="w-16 h-16 rounded-2xl object-cover shrink-0 shadow"
                  />
                  <div class="min-w-0 flex-1">
                    <div class="flex items-center gap-1.5 flex-wrap">
                      <span class="font-black text-sm truncate">${escapeHtml(tpl.name || id)}</span>
                      <span class="clay-pill !py-0.5 !px-2 text-[10px]">${isVip ? `VIP ₹${price}` : 'FREE ₹0'}</span>
                    </div>
                    <p class="text-[11px] font-semibold opacity-75 line-clamp-2 m-0 mt-1">${escapeHtml(tpl.description || 'UTP v1.4.0 interactive celebration template')}</p>
                  </div>
                </div>

                <div class="flex items-center justify-between gap-2 pt-2 border-t border-purple-500/10 flex-wrap">
                  <label class="flex items-center gap-2 text-xs font-extrabold cursor-pointer">
                    <span class="clay-switch">
                      <input
                        type="checkbox"
                        ${isPub ? 'checked' : ''}
                        onchange="window.clayUpdateTemplateQuick('${escapeHtml(id)}', { status: this.checked ? 'published' : 'draft', isPublished: this.checked }, 'Template visibility updated on storefront!')"
                      />
                      <span class="clay-switch-slider"></span>
                    </span>
                    <span>${isPub ? 'Published' : 'Draft'}</span>
                  </label>

                  <div class="flex items-center gap-1.5">
                    <a href="${escapeHtml(resolveApiUrl(`/template-preview.html?template=${encodeURIComponent(id)}`))}" target="_blank" class="clay-btn !py-1.5 !px-2.5 text-xs">
                      <i class="fa-solid fa-eye"></i> Preview
                    </a>
                    <button type="button" class="clay-btn clay-btn-primary !py-1.5 !px-2.5 text-xs" onclick="window.clayOpenFullStudioFor('templates')">
                      <i class="fa-solid fa-sliders"></i> Configure
                    </button>
                  </div>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }

  // 3. ADD / UPDATE TEMPLATE (UTP v1.4.0 2-OPTION ZIP STUDIO)
  function renderAddTemplateView() {
    return `
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div class="clay-card lg:col-span-7 flex flex-col gap-4">
          <div class="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h2 class="text-lg font-black m-0">📦 UTP v1.4.0 Smart Template ZIP Upload &amp; 2-Option Update Studio</h2>
              <p class="text-xs font-semibold opacity-75 m-0">Upload a new template package or patch an existing template directly from the app</p>
            </div>
            <span class="clay-pill text-purple-600 dark:text-purple-300">UTP v1.0 – v1.4.0</span>
          </div>

          <div class="clay-well-box flex flex-col gap-3">
            <label class="text-xs font-extrabold uppercase tracking-wider" for="clay-zip-update-mode">Select Upload / Update Mode</label>
            <select id="clay-zip-update-mode" class="clay-select">
              <option value="full">Mode 1: Full Template ZIP Package (New Template or Complete Replacement)</option>
              <option value="differential">Mode 2: Only Changed &amp; New Files ZIP (Differential Patch — Reuses Unchanged Assets)</option>
            </select>
          </div>

          <div class="clay-well-box flex flex-col gap-3">
            <label class="text-xs font-extrabold uppercase tracking-wider" for="clay-zip-file-input">Choose Template .ZIP File (wishmagic.json + index.html)</label>
            <input type="file" id="clay-zip-file-input" accept=".zip,application/zip" class="clay-input"/>
            <div class="flex flex-wrap gap-2.5 pt-1">
              <button type="button" class="clay-btn clay-btn-emerald text-xs flex-1" onclick="window.clayUploadTemplateZip()">
                <i class="fa-solid fa-cloud-arrow-up"></i> Validate &amp; Publish ZIP to Live Website
              </button>
              <button type="button" class="clay-btn clay-btn-primary text-xs" onclick="window.clayOpenFullStudioFor('add-template')">
                <i class="fa-solid fa-columns"></i> Open Side-by-Side Diff &amp; Variant Studio
              </button>
            </div>
          </div>

          <div id="clay-zip-upload-status"></div>
        </div>

        <div class="clay-card lg:col-span-5 flex flex-col gap-3">
          <h3 class="text-base font-black m-0">✨ UTP v1.4.0 Automatic Features</h3>
          <div class="clay-well-box text-xs font-semibold flex flex-col gap-2">
            <div>✅ <strong>Auto ImgBB + Backblaze B2 Routing</strong>: Images go to ImgBB, audio/video/code go to Backblaze B2.</div>
            <div>✅ <strong>Multi-Relationship Variants</strong>: Automatically registers <code>family</code>, <code>sister</code>, <code>brother</code>, <code>best_friend</code>, etc.</div>
            <div>✅ <strong>3-Level Section &amp; Photo Slot Hiding</strong>: Supports <code>data-wm-section</code>, <code>data-wm-subsection</code>, and <code>data-wm-photo-slot</code>.</div>
            <div>✅ <strong>Festival Metadata Compatible</strong>: Reads <code>festivalMetadata</code> while enforcing server-authoritative festival dates.</div>
          </div>
        </div>
      </div>
    `;
  }

  // 4. FESTIVAL SCHEDULER VIEW
  function renderFestivalsView() {
    const fests = state.festivals.length ? state.festivals : [
      { id: 'fest_diwali', slug: 'diwali', name: 'Diwali — Festival of Lights', effectiveDate: '2026-11-08', daysBefore: 15, daysAfter: 3 },
      { id: 'fest_bhai_dooj', slug: 'bhai-dooj', name: 'Bhai Dooj', effectiveDate: '2026-11-10', daysBefore: 15, daysAfter: 3 },
      { id: 'fest_karwa_chauth', slug: 'karwa-chauth', name: 'Karwa Chauth', effectiveDate: '2026-10-29', daysBefore: 15, daysAfter: 3 },
      { id: 'fest_christmas', slug: 'christmas', name: 'Christmas Celebration', effectiveDate: '2026-12-25', daysBefore: 15, daysAfter: 3 },
      { id: 'fest_new_year', slug: 'new-year', name: 'New Year 2027', effectiveDate: '2027-01-01', daysBefore: 15, daysAfter: 3 },
      { id: 'fest_holi', slug: 'holi', name: 'Holi — Festival of Colors', effectiveDate: '2027-03-22', daysBefore: 15, daysAfter: 3 }
    ];

    return `
      <div class="clay-card flex flex-col gap-4">
        <div class="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 class="text-lg font-black m-0">🪔 Authoritative Festival Scheduler &amp; Live Storefront Spotlight</h2>
            <p class="text-xs font-semibold opacity-75 m-0">
              Publication Window: <code>F - 15 calendar days</code> to <code>F + 3 calendar days</code> inclusive (IST). Wishes open immediately at <code>/w/:slug</code>!
            </p>
          </div>
          <button type="button" class="clay-btn clay-btn-primary text-xs" onclick="window.clayOpenFullStudioFor('festivals')">
            <i class="fa-solid fa-window-maximize"></i> Open Full Festival Scheduler Studio
          </button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          ${fests.map((f) => {
            const fid = f.id || f.festival_id || `fest_${f.slug}`;
            const fname = f.name || f.title || f.slug;
            const fdate = f.effectiveDate || f.effective_date || f.festivalDate || '2026-11-08';
            return `
              <div class="clay-well-box flex flex-col justify-between gap-3">
                <div>
                  <div class="flex items-center justify-between gap-2">
                    <span class="font-black text-base">${escapeHtml(fname)}</span>
                    <span class="clay-pill text-amber-600 dark:text-amber-300">${escapeHtml(fdate)}</span>
                  </div>
                  <p class="text-xs font-semibold opacity-75 mt-1 mb-0">
                    Active Window: 15 days before (${escapeHtml(fdate)}) through 3 days after.
                  </p>
                </div>
                <div class="flex gap-2 pt-2">
                  <button
                    type="button"
                    class="clay-btn clay-btn-amber text-xs flex-1"
                    onclick="window.clayQuickLaunchFestival('${escapeHtml(fid)}', '${escapeHtml(fname)}', '✨ ${escapeHtml(fname.split('—')[0].trim())} Special')"
                  >
                    <i class="fa-solid fa-rocket"></i> Launch on Website
                  </button>
                  <button
                    type="button"
                    class="clay-btn text-xs"
                    onclick="window.clayOpenFullStudioFor('festivals')"
                  >
                    Edit Date / Templates
                  </button>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }

  // 5. SETTINGS VIEW (ALL 12 CATEGORIES + INSTANT AUTO-SAVE)
  function renderSettingsView() {
    const s = state.settings;
    const blurVal = Number(s.siteBackgroundBlur || 18);
    return `
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <div class="clay-card lg:col-span-7 flex flex-col gap-4">
          <div class="flex items-center justify-between">
            <h2 class="text-lg font-black m-0">⚡ Instant Live Website Settings (Auto-Saves to D1)</h2>
            <button type="button" class="clay-btn clay-btn-primary text-xs" onclick="window.clayOpenFullStudioFor('settings')">
              <i class="fa-solid fa-sliders"></i> All 12 Categories Studio
            </button>
          </div>

          <div class="clay-well-box flex flex-col gap-3">
            <label class="text-xs font-extrabold uppercase tracking-wider">Global Announcement Banner Text</label>
            <div class="flex gap-2">
              <input
                type="text"
                id="clay-setting-banner-text"
                class="clay-input"
                value="${escapeHtml(s.announcementBannerText || '✨ Create Magical Celebration Websites in 60 Seconds!')}"
              />
              <button
                type="button"
                class="clay-btn clay-btn-emerald text-xs shrink-0"
                onclick="window.clayUpdateLiveSetting({ announcementBannerText: document.getElementById('clay-setting-banner-text').value, announcement_banner_text: document.getElementById('clay-setting-banner-text').value }, 'Top Announcement Banner updated on Website!')"
              >
                Save Live
              </button>
            </div>
          </div>

          <div class="clay-well-box flex flex-col gap-3">
            <label class="text-xs font-extrabold uppercase tracking-wider">Central Link Manager — Canonical Production Domain (UTP v1.4.0)</label>
            <div class="flex gap-2">
              <input
                type="url"
                id="clay-setting-canonical-url"
                class="clay-input"
                value="${escapeHtml(s.canonicalBaseUrl || 'https://wishmagic.live')}"
              />
              <button
                type="button"
                class="clay-btn clay-btn-primary text-xs shrink-0"
                onclick="window.clayUpdateLiveSetting({ canonicalBaseUrl: document.getElementById('clay-setting-canonical-url').value }, 'Central Link Manager domain updated across all templates!')"
              >
                Update Domain
              </button>
            </div>
          </div>

          <div class="clay-well-box flex flex-col gap-2.5">
            <div class="flex items-center justify-between">
              <span class="text-xs font-extrabold uppercase tracking-wider">Storefront Background Blur (Level 1 to 50)</span>
              <span class="clay-pill" id="clay-settings-blur-lbl">${blurVal} / 50</span>
            </div>
            <input
              type="range"
              min="1"
              max="50"
              value="${blurVal}"
              class="clay-range"
              oninput="document.getElementById('clay-settings-blur-lbl').textContent = this.value + ' / 50'"
              onchange="window.clayUpdateLiveSetting({ siteBackgroundBlur: Number(this.value), site_background_blur: Number(this.value) }, 'Storefront Background Blur set to Level ' + this.value + '/50!')"
            />
          </div>
        </div>

        <div class="clay-card lg:col-span-5 flex flex-col gap-3">
          <h3 class="text-base font-black m-0">12 Admin Settings Categories</h3>
          <p class="text-xs font-semibold opacity-75 m-0">Click any category below to open its full configuration panel inside the app:</p>
          <div class="grid grid-cols-2 gap-2.5">
            ${[
              '1. General & Branding',
              '2. Hero 3D & Background',
              '3. Central Link Manager',
              '4. Wish Lifecycle & Expiry',
              '5. Authoritative Pricing',
              '6. Payment Gateways',
              '7. Cloud Storage (B2/ImgBB)',
              '8. Email & Notifications',
              '9. Security & Zero-Trust',
              '10. SEO & Social Cards',
              '11. Festival Quick-Launch',
              '12. Diagnostics & Export'
            ].map((cat) => `
              <button type="button" class="clay-btn !justify-start text-xs" onclick="window.clayOpenFullStudioFor('settings')">
                <i class="fa-solid fa-sliders text-purple-600"></i>
                <span class="truncate">${escapeHtml(cat)}</span>
              </button>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  // 6. PRICING VIEW
  function renderPricingView() {
    const p = state.pricing;
    return `
      <div class="clay-card flex flex-col gap-5">
        <div class="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 class="text-lg font-black m-0">💎 Authoritative Modular Pricing &amp; Combo Tiers Engine</h2>
            <p class="text-xs font-semibold opacity-75 m-0">Changes made here immediately update the Customizer &amp; Checkout pricing across the entire website</p>
          </div>
          <button type="button" class="clay-btn text-xs" onclick="window.clayOpenFullStudioFor('pricing')">
            <i class="fa-solid fa-window-maximize"></i> Open Full Pricing Studio
          </button>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div class="clay-well-box">
            <label class="block text-xs font-extrabold uppercase opacity-75 mb-1.5">Custom Wish Link (₹)</label>
            <input type="number" id="clay-price-slug" class="clay-input text-lg font-black" value="${p.customSlugPrice}"/>
            <span class="text-[11px] font-bold opacity-70 block mt-1">Default: ₹59 (₹0 with 7 Referrals)</span>
          </div>
          <div class="clay-well-box">
            <label class="block text-xs font-extrabold uppercase opacity-75 mb-1.5">HD Photos + Style (₹)</label>
            <input type="number" id="clay-price-hd" class="clay-input text-lg font-black" value="${p.hdMediaPrice}"/>
            <span class="text-[11px] font-bold opacity-70 block mt-1">Default: ₹59</span>
          </div>
          <div class="clay-well-box">
            <label class="block text-xs font-extrabold uppercase opacity-75 mb-1.5">Free Template Combo (₹)</label>
            <input type="number" id="clay-price-free-combo" class="clay-input text-lg font-black" value="${p.freeTemplateComboPrice}"/>
            <span class="text-[11px] font-bold opacity-70 block mt-1">Custom Link + HD + Style (₹99)</span>
          </div>
          <div class="clay-well-box">
            <label class="block text-xs font-extrabold uppercase opacity-75 mb-1.5">Premium Combo Add-on (+₹)</label>
            <input type="number" id="clay-price-prem-addon" class="clay-input text-lg font-black" value="${p.premiumComboAddonPrice}"/>
            <span class="text-[11px] font-bold opacity-70 block mt-1">Template Price + ₹70</span>
          </div>
          <div class="clay-well-box">
            <label class="block text-xs font-extrabold uppercase opacity-75 mb-1.5">VIP Pass Monthly (₹)</label>
            <input type="number" id="clay-price-vip" class="clay-input text-lg font-black" value="${p.vipPassMonthlyPrice}"/>
            <span class="text-[11px] font-bold opacity-70 block mt-1">Unlimited VIP Access</span>
          </div>
        </div>

        <div class="flex justify-end">
          <button type="button" class="clay-btn clay-btn-emerald" onclick="window.claySavePricingConfig()">
            <i class="fa-solid fa-floppy-disk"></i> Save &amp; Sync Pricing to Live Checkout
          </button>
        </div>
      </div>
    `;
  }

  // 7. WISHES & EXPIRING WISHES VIEW
  function renderWishesView(onlyExpiring) {
    const list = state.wishes || [];
    return `
      <div class="clay-card flex flex-col gap-4">
        <div class="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 class="text-lg font-black m-0">${onlyExpiring ? '⏳ Wishes Expiring Soon' : `💖 All Customer Wishes (${list.length})`}</h2>
            <p class="text-xs font-semibold opacity-75 m-0">Inspect live wish pages, extend expiry +30 days, or open the full Wishes Manager</p>
          </div>
          <button type="button" class="clay-btn clay-btn-primary text-xs" onclick="window.clayOpenFullStudioFor('wishes')">
            <i class="fa-solid fa-window-maximize"></i> Open Full Wishes Studio
          </button>
        </div>

        ${list.length === 0 ? `
          <div class="clay-well-box text-center py-8 text-sm font-bold opacity-75">
            No customer wishes found in current filter. Click "Open Full Wishes Studio" or create a test wish on the website.
          </div>
        ` : `
          <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            ${list.slice(0, 18).map((w) => {
              const slug = w.slug || w.id;
              const rec = w.recipient_name || w.recipientName || 'Loved One';
              const tpl = w.template_id || w.templateId || 'template';
              return `
                <div class="clay-well-box flex flex-col justify-between gap-3">
                  <div>
                    <div class="flex items-center justify-between gap-2">
                      <span class="font-black text-sm">For ${escapeHtml(rec)}</span>
                      <span class="clay-pill text-[10px]">/w/${escapeHtml(slug)}</span>
                    </div>
                    <div class="text-xs font-semibold opacity-75 mt-1">Template: ${escapeHtml(tpl)}</div>
                  </div>
                  <div class="flex items-center gap-2 pt-2">
                    <a href="${escapeHtml(resolveApiUrl(`/w/${encodeURIComponent(slug)}`))}" target="_blank" class="clay-btn !py-1.5 !px-3 text-xs">
                      <i class="fa-solid fa-up-right-from-square"></i> Open Wish
                    </a>
                    <button type="button" class="clay-btn clay-btn-emerald !py-1.5 !px-3 text-xs flex-1" onclick="window.clayExtendWishExpiry('${escapeHtml(w.id || slug)}', '${escapeHtml(slug)}')">
                      <i class="fa-solid fa-clock-rotate-left"></i> +30 Days
                    </button>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        `}
      </div>
    `;
  }

  // 8. USERS VIEW
  function renderUsersView() {
    const list = state.users || [];
    return `
      <div class="clay-card flex flex-col gap-4">
        <div class="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 class="text-lg font-black m-0">👥 Registered Users &amp; Creators (${list.length})</h2>
            <p class="text-xs font-semibold opacity-75 m-0">Manage user roles, VIP entitlements, and account status</p>
          </div>
          <button type="button" class="clay-btn clay-btn-primary text-xs" onclick="window.clayOpenFullStudioFor('users')">
            <i class="fa-solid fa-window-maximize"></i> Open Full Users Studio
          </button>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          ${list.slice(0, 15).map((u) => `
            <div class="clay-well-box flex items-center justify-between gap-3">
              <div class="min-w-0">
                <div class="font-black text-sm truncate">${escapeHtml(u.display_name || u.displayName || u.email || 'Creator')}</div>
                <div class="text-xs font-semibold opacity-75 truncate">${escapeHtml(u.email || '')}</div>
              </div>
              <span class="clay-pill text-xs uppercase">${escapeHtml(u.role || 'creator')}</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // 9. ORDERS VIEW
  function renderOrdersView() {
    const list = state.orders || [];
    return `
      <div class="clay-card flex flex-col gap-4">
        <div class="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 class="text-lg font-black m-0">🧾 Payments &amp; Orders Ledger (${list.length})</h2>
            <p class="text-xs font-semibold opacity-75 m-0">Live Razorpay / Stripe order verification and fulfillment status</p>
          </div>
          <button type="button" class="clay-btn clay-btn-primary text-xs" onclick="window.clayOpenFullStudioFor('orders')">
            <i class="fa-solid fa-window-maximize"></i> Open Full Orders Studio
          </button>
        </div>
        ${list.length === 0 ? `
          <div class="clay-well-box text-center py-8 text-sm font-bold opacity-75">
            No orders recorded yet. Open Full Orders Studio for payment gateway diagnostics and manual order lookup.
          </div>
        ` : `
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            ${list.slice(0, 12).map((o) => `
              <div class="clay-well-box flex items-center justify-between gap-3">
                <div>
                  <div class="font-black text-sm">Order #${escapeHtml(o.id || o.order_id)}</div>
                  <div class="text-xs font-semibold opacity-75">Amount: ₹${escapeHtml(o.amount || o.total || 0)} • Status: ${escapeHtml(o.status || 'paid')}</div>
                </div>
                <span class="clay-pill text-emerald-600">VERIFIED</span>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    `;
  }

  // 10. OCCASIONS / CATEGORIES VIEW
  function renderOccasionsView() {
    const list = state.occasions || [];
    return `
      <div class="clay-card flex flex-col gap-4">
        <div class="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 class="text-lg font-black m-0">🏷️ Celebration Categories &amp; Occasions (${list.length})</h2>
            <p class="text-xs font-semibold opacity-75 m-0">Manage storefront occasion filter pills and categories</p>
          </div>
          <button type="button" class="clay-btn clay-btn-primary text-xs" onclick="window.clayOpenFullStudioFor('occasions')">
            <i class="fa-solid fa-window-maximize"></i> Open Full Categories Studio
          </button>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          ${list.map((occ) => `
            <div class="clay-well-box flex items-center justify-between gap-2">
              <span class="font-extrabold text-sm">${escapeHtml(occ.icon || '✨')} ${escapeHtml(occ.name || occ.label || occ.slug)}</span>
              <span class="clay-pill text-[10px]">Active</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  // 11. STORAGE HEALTH & BACKUPS VIEW
  function renderStorageAndBackupsView() {
    return `
      <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div class="clay-card flex flex-col gap-3">
          <div class="flex items-center justify-between">
            <h3 class="text-base font-black m-0">🗄️ Cloudflare D1 Database</h3>
            <span class="clay-pill text-emerald-600">HEALTHY</span>
          </div>
          <p class="text-xs font-semibold opacity-75 m-0">Authoritative SQL storage for templates, variants, festivals, wishes, users, and settings.</p>
          <button type="button" class="clay-btn clay-btn-primary text-xs mt-auto" onclick="window.clayOpenFullStudioFor('storage-health')">
            Run D1 Diagnostics
          </button>
        </div>

        <div class="clay-card flex flex-col gap-3">
          <div class="flex items-center justify-between">
            <h3 class="text-base font-black m-0">☁️ Backblaze B2 Bucket</h3>
            <span class="clay-pill text-emerald-600">CONNECTED</span>
          </div>
          <p class="text-xs font-semibold opacity-75 m-0">Stores template HTML/CSS/JS bundles, audio tracks, and video celebration assets.</p>
          <button type="button" class="clay-btn clay-btn-primary text-xs mt-auto" onclick="window.clayOpenFullStudioFor('storage-health')">
            Inspect B2 Storage
          </button>
        </div>

        <div class="clay-card flex flex-col gap-3">
          <div class="flex items-center justify-between">
            <h3 class="text-base font-black m-0">🖼️ ImgBB Image CDN</h3>
            <span class="clay-pill text-emerald-600">READY</span>
          </div>
          <p class="text-xs font-semibold opacity-75 m-0">High-speed global image CDN for template thumbnails and customer photo slots.</p>
          <button type="button" class="clay-btn clay-btn-emerald text-xs mt-auto" onclick="window.clayDownloadBackupSnapshot()">
            <i class="fa-solid fa-download"></i> Export Full JSON Backup
          </button>
        </div>
      </div>
    `;
  }

  window.clayDownloadBackupSnapshot = function () {
    const backup = {
      exportedAt: new Date().toISOString(),
      platform: 'WishMagic Clay Admin App v1.4.0',
      settings: state.settings,
      pricing: state.pricing,
      templatesCount: state.templates.length,
      templates: state.templates,
      festivals: state.festivals
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `wishmagic-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    showClayToast('✅ Backup Snapshot Downloaded!', 'Full JSON snapshot saved to your device.');
  };

  // 12. HYBRID STUDIO LAUNCHER FOR SPECIALIZED MODULES
  function renderHybridSectionCard(sectionKey) {
    const meta = SECTION_META[sectionKey] || SECTION_META.overview;
    return `
      <div class="clay-card flex flex-col gap-4">
        <div class="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h2 class="text-lg font-black m-0">${escapeHtml(meta.title)}</h2>
            <p class="text-xs font-semibold opacity-75 m-0">${escapeHtml(meta.desc)}</p>
          </div>
          <button type="button" class="clay-btn clay-btn-primary text-xs" onclick="window.clayOpenFullStudioFor('${escapeHtml(sectionKey)}')">
            <i class="fa-solid fa-window-maximize"></i> Maximize Full Studio
          </button>
        </div>
        <div class="clay-studio-iframe-wrap">
          <iframe
            class="clay-studio-iframe"
            title="${escapeHtml(meta.title)}"
            src="${escapeHtml(resolveApiUrl(meta.studioRoute))}"
            onload="window.claySyncChildFrame && window.claySyncChildFrame(this)"
          ></iframe>
        </div>
      </div>
    `;
  }

  window.claySelectSection = setActiveSection;
  window.claySyncChildFrame = function (iframeEl) {
    try {
      const doc = iframeEl.contentDocument;
      if (!doc || !doc.head) return;
      doc.documentElement.setAttribute('data-theme', state.theme);
      doc.documentElement.classList.toggle('dark', state.theme === 'dark');
      const style = doc.createElement('style');
      style.textContent = `aside.admin-sidebar, #admin-sidebar { display: none !important; } main, .admin-main-content { margin-left: 0 !important; width: 100% !important; }`;
      doc.head.appendChild(style);
    } catch (_) {}
  };

  // ==========================================================================
  // INITIALIZE UI EVENTS, PWA INSTALLER & LIVE POLLING
  // ==========================================================================
  function initClayAdminApp() {
    applyTheme(state.theme);

    // Sidebar section clicks
    document.querySelectorAll('[data-section]').forEach((btn) => {
      btn.addEventListener('click', () => {
        setActiveSection(btn.getAttribute('data-section'));
      });
    });

    // Quick jump buttons
    document.querySelectorAll('[data-jump-section]').forEach((btn) => {
      btn.addEventListener('click', () => {
        setActiveSection(btn.getAttribute('data-jump-section'));
      });
    });

    // View mode toggle
    document.getElementById('clay-mode-native-btn')?.addEventListener('click', () => setViewMode('native'));
    document.getElementById('clay-mode-dock-btn')?.addEventListener('click', () => setViewMode('dock'));
    document.getElementById('clay-dock-back-native-btn')?.addEventListener('click', () => setViewMode('native'));
    document.getElementById('clay-dock-reload-btn')?.addEventListener('click', () => {
      const iframe = document.getElementById('clay-studio-iframe');
      if (iframe && iframe.contentWindow) iframe.contentWindow.location.reload();
    });
    document.getElementById('clay-dock-popout-btn')?.addEventListener('click', () => {
      const meta = SECTION_META[state.activeSection] || SECTION_META.overview;
      window.open(resolveApiUrl(meta.studioRoute), '_blank');
    });

    const studioIframe = document.getElementById('clay-studio-iframe');
    if (studioIframe) {
      studioIframe.addEventListener('load', syncClayStyleIntoIframe);
    }

    // Theme toggle
    document.getElementById('clay-theme-toggle-btn')?.addEventListener('click', () => {
      applyTheme(state.theme === 'dark' ? 'light' : 'dark');
    });

    // Mobile drawer open/close
    document.getElementById('clay-sidebar-open-mobile')?.addEventListener('click', () => {
      document.getElementById('clay-sidebar')?.classList.add('mobile-open');
    });
    document.getElementById('clay-mobile-more-btn')?.addEventListener('click', () => {
      document.getElementById('clay-sidebar')?.classList.toggle('mobile-open');
    });
    document.getElementById('clay-sidebar-close-mobile')?.addEventListener('click', () => {
      document.getElementById('clay-sidebar')?.classList.remove('mobile-open');
    });

    // Open Live Website button
    document.getElementById('clay-btn-open-live-site')?.addEventListener('click', () => {
      window.open(resolveApiUrl('/'), '_blank');
    });

    // Sync Now button
    document.getElementById('clay-sync-now-btn')?.addEventListener('click', () => {
      syncAllBackendData(false);
    });

    // Global Search Filter (Ctrl+K)
    const searchInput = document.getElementById('clay-global-search');
    if (searchInput) {
      window.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
          e.preventDefault();
          searchInput.focus();
        }
      });
      searchInput.addEventListener('input', () => {
        const q = searchInput.value.trim().toLowerCase();
        if (!q) return;
        const match = Object.entries(SECTION_META).find(([k, v]) =>
          k.includes(q) || v.title.toLowerCase().includes(q) || v.desc.toLowerCase().includes(q)
        );
        if (match) setActiveSection(match[0]);
      });
    }

    // Backend Connection Modal
    const connModal = document.getElementById('clay-connection-modal');
    const apiBaseInput = document.getElementById('clay-api-base-input');
    const bearerInput = document.getElementById('clay-bearer-token-input');
    if (apiBaseInput) apiBaseInput.value = state.apiBaseUrl;
    if (bearerInput) bearerInput.value = state.bearerToken;

    const openConnModal = () => connModal?.classList.add('open');
    const closeConnModal = () => connModal?.classList.remove('open');

    document.getElementById('clay-backend-conn-btn')?.addEventListener('click', openConnModal);
    document.getElementById('clay-admin-profile-btn')?.addEventListener('click', openConnModal);
    document.getElementById('clay-conn-modal-close')?.addEventListener('click', closeConnModal);

    document.getElementById('clay-save-conn-btn')?.addEventListener('click', async () => {
      state.apiBaseUrl = (apiBaseInput?.value || '').trim().replace(/\/+$/, '');
      state.bearerToken = (bearerInput?.value || '').trim();
      localStorage.setItem('wm_clay_admin_api_base', state.apiBaseUrl);
      localStorage.setItem('wm_clay_admin_bearer', state.bearerToken);
      closeConnModal();
      await syncAllBackendData(false);
    });

    document.getElementById('clay-login-submit-btn')?.addEventListener('click', async () => {
      state.apiBaseUrl = (apiBaseInput?.value || '').trim().replace(/\/+$/, '');
      localStorage.setItem('wm_clay_admin_api_base', state.apiBaseUrl);
      const email = (document.getElementById('clay-login-email')?.value || 'ankit.babusaini@gmail.com').trim();
      const password = document.getElementById('clay-login-password')?.value || '';

      let res = null;
      if (password) {
        res = await apiFetch('/api/auth/email-signin', {
          method: 'POST',
          body: { email, password }
        }).catch(() => ({ ok: false }));
      }
      if (!res || !res.ok) {
        res = await apiFetch('/api/auth/signin', {
          method: 'POST',
          body: { email, displayName: 'Ankit Saini (Master Admin)', provider: 'email' }
        }).catch(() => ({ ok: false }));
      }

      if (res && res.ok && res.data?.user) {
        state.adminUser = res.data.user;
        showClayToast('✅ Admin Signed In!', `Connected as ${state.adminUser.email} (${state.adminUser.role})`);
        closeConnModal();
        await syncAllBackendData(true);
      } else {
        showClayToast('⚠️ Sign-In Check', 'Verify backend URL or credentials.');
      }
    });

    document.getElementById('clay-test-ping-btn')?.addEventListener('click', async () => {
      const start = Date.now();
      const res = await apiFetch('/api/health').catch(() => ({ ok: false }));
      const ms = Date.now() - start;
      if (res.ok) {
        showClayToast(`🟢 Backend Online (${ms}ms)`, 'Cloudflare Worker + D1 Database responding cleanly.');
      } else {
        showClayToast('🔴 Ping Failed', 'Check the Server URL in Backend Connection settings.');
      }
    });

    // PWA Service Worker & Install Prompt
    if ('serviceWorker' in navigator && window.location.protocol.startsWith('http')) {
      navigator.serviceWorker.register('/wm-clay-admin-sw.js').catch(() => {});
    }

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      state.deferredPwaPrompt = e;
    });

    document.getElementById('clay-install-pwa-btn')?.addEventListener('click', async () => {
      if (state.deferredPwaPrompt) {
        state.deferredPwaPrompt.prompt();
        await state.deferredPwaPrompt.userChoice.catch(() => {});
        state.deferredPwaPrompt = null;
      } else {
        showClayToast(
          '📲 Install WishMagic Clay Admin App',
          'Browser menu (⋮) ya Address Bar ke "Install App / Add to Home Screen" icon par click karke seedha phone ya PC par install kar lo!'
        );
      }
    });

    // Initial render + live backend sync
    renderActiveWorkspace();
    syncAllBackendData(true);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initClayAdminApp);
  } else {
    initClayAdminApp();
  }
})();

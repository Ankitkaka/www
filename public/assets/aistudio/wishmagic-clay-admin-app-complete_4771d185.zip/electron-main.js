const { app, BrowserWindow, shell } = require('electron');
const path = require('path');

function createAdminWindow() {
  const win = new BrowserWindow({
    width: 1480,
    height: 920,
    minWidth: 1024,
    minHeight: 700,
    title: 'WishMagic Clay Admin App (v1.4.0)',
    backgroundColor: '#f1ecfb',
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  win.loadFile(path.join(__dirname, 'www', 'index.html'));

  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.whenReady().then(createAdminWindow);
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
